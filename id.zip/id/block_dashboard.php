<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_dashboard', language 'id', version '4.5'.
 *
 * @package     block_dashboard
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['configtabular_help'] = '<h3>Hasil tabel</h3>
p>Tampilan tabel menampilkan hasil kueri dalam tabel dua dimensi, menggunakan bidang keluaran khusus untuk menghasilkan kolom dan satu set bidang untuk menghasilkan teks baris yang terorganisir secara hierarkis.</p>
<p>Data yang dicetak dalam sel adalah nilai dari "bidang keluaran" yang ditentukan, atau jika telah didefinisikan sebagai daftar, n-uplet nilai yang berasal dari bidang keluaran yang sesuai.';
$string['configtreeoutput_help'] = '<p>bidang ini berisi daftar kolom yang menyediakan keterangan simpul pohon.</p>';
